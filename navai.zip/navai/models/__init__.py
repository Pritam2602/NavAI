"""Model wrappers for NAVAI."""

