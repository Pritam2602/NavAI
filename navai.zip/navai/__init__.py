"""NAVAI autonomous navigation backend."""

